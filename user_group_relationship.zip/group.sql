/*
-- Query: SELECT * FROM ssdi_project.groups
LIMIT 0, 1000

-- Date: 2017-03-26 20:28
*/
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`) VALUES (3,'Uncc_49ers','UNCC Students Group');
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`) VALUES (4,'Laser Tag Corps','Laser tag group,We play every Wed and Sunday at 5pm,Come Join us');
