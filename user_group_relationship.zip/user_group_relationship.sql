/*
-- Query: SELECT * FROM ssdi_project.user_group_relationship
LIMIT 0, 1000

-- Date: 2017-03-26 20:28
*/
INSERT INTO `user_group_relationship` (`user_group_id`,`user_id`,`group_id`) VALUES (1,2,4);
INSERT INTO `user_group_relationship` (`user_group_id`,`user_id`,`group_id`) VALUES (2,4,4);
INSERT INTO `user_group_relationship` (`user_group_id`,`user_id`,`group_id`) VALUES (3,2,3);
