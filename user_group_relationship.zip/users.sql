/*
-- Query: SELECT * FROM ssdi_project.users
LIMIT 0, 1000

-- Date: 2017-03-26 20:29
*/
INSERT INTO `users` (`u_id`,`u_emailid`,`u_password`,`u_Name`) VALUES (1,'johnsmith@gmail.com','John','John Smith');
INSERT INTO `users` (`u_id`,`u_emailid`,`u_password`,`u_Name`) VALUES (2,'janedoe@yahoo.com','Jane','Jane Doe');
INSERT INTO `users` (`u_id`,`u_emailid`,`u_password`,`u_Name`) VALUES (4,'vinu0404@gmail.com','Vinu','Viranchi Deshpande');
